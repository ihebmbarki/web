<?PHP
include "../config.php";
class eventC{
 function ajouterEvent($event){
		$sql="insert into evennement (nom,theme) values (:nom,:theme)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $nom=$event->getnom();
        $theme=$event->gettheme();
		$req->bindValue(':nom',$nom);
		$req->bindValue(':theme',$theme);
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}

}
?>
