<?php
include "config.php";
class crud{
	private $cnx;
	function __construct(){
		$this->cnx=config::getConnexion();
	}
    public function trier()
    {
        $sql = "SELECT * FROM  event ORDER BY nom ASC";
        $db = config::getConnexion();
        try {
            $sth = $db->prepare($sql);
            $sth->execute();
            $liste = $sth->fetchAll();
            return $liste;
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }
	function ajouter($event){
		$nom=$event->getNom();
		$theme=$event->getTheme();
		$sql = "INSERT INTO event (nom,theme) Values('$nom','$theme')";
		try{
			$this->cnx->exec($sql);
		}
		catch(Exception $e){
			echo "ERREUUUUR : " .$e->getMessage();
		}
	}
	function afficherEvents(){
        $sql="SELECT * FROM event";
        $resultat=$this->cnx->query($sql);
        return $resultat->fetchAll();
    }
    function deleteEvent($id){
        $db = config::getConnexion();
        $req="DELETE FROM event where id=$id";
        $db->exec($req);
    }
     function getEvent($id){
        $sql="SELECT * from event where id=$id";
        $res=$this->cnx->query($sql);
        return $res->fetch();

    }


    function modifierEvent($event,$id){
        $sql="UPDATE event SET nom=:nom,theme=:theme WHERE id=:id";

        $db = config::getConnexion();
        //$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
        try{
            $req=$db->prepare($sql);

            $nom=$event->getNom();
            $theme=$event->getTheme();
            $datas = array(
                ':id'=>$id, ':nom'=>$nom,
                ':theme'=>$theme);

            $req->bindValue(':id',$id);
            $req->bindValue(':nom',$nom);
            $req->bindValue(':theme',$theme);


            $s=$req->execute();

            // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
            echo " Les datas : " ;
            print_r($datas);
        }


    }


    function ajouterPlanning($planning){
        $lieu=$planning->getLieu();
        $dat=$planning->getDat();
        $sql = "INSERT INTO planning (lieu,dat) Values('$lieu','$dat')";
        try{
            $this->cnx->exec($sql);
        }
        catch(Exception $e){
            echo "ERREUUUUR : " .$e->getMessage();
        }
    }

        function afficherPlannings(){
        $sql="SELECT * FROM planning";
        $resultat=$this->cnx->query($sql);
        return $resultat->fetchAll();
    }
    function deletePlanning($id){
        $db = config::getConnexion();
        $req="DELETE FROM planning where id=$id";
        $db->exec($req);
    }
     function getPlanning($id){
        $sql="SELECT * from planning where id=$id";
        $res=$this->cnx->query($sql);
        return $res->fetch();

    }


    function modifierPlanning($planning,$id){
        $sql="UPDATE planning SET lieu=:lieu,dat=:dat WHERE id=:id";

        $db = config::getConnexion();
        //$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
        try{
            $req=$db->prepare($sql);

            $lieu=$planning->getLieu();
            $dat=$planning->getDat();
            $datas = array(
                ':id'=>$id, ':lieu'=>$lieu,
                ':dat'=>$dat);

            $req->bindValue(':id',$id);
            $req->bindValue(':lieu',$lieu);
            $req->bindValue(':dat',$dat);


            $s=$req->execute();

            // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
            echo " Les datas : " ;
            print_r($datas);
        }


    }


}