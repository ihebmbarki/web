<?php
include "Event.php";
include "crud.php";

$eve=new Event();
$eve->setNom($_POST['nom']);
$eve->setTheme($_POST['theme']);
$cru=new crud();
$cru->ajouter($eve);

header("location:index.php");