<?php

include  "crud.php";


$id=$_GET['id'];

$c=new crud();
$c->deletePlanning($id);
header("Location: index.php");
?>
<html lang="en">
<head>
	<meta charset="utf-8">
	<link href="css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<br />
<div class="container">
     

<br />
<div class="span10 offset1">

<br />
<div class="row">

<br />
<h3>Delete an event</h3>
<p>

</div>
<p>

                     
<br />
<form class="form-horizontal" action="supprimerPlanning.php" method="post">
                      <input type="hidden" name="id" value="<?php echo $id;?>"/>
                      
Are you sure to delete ?

<br />
<div class="form-actions">
                          <button type="submit" class="btn btn-danger">Yes</button>
                          <a class="btn" href="index.php">No</a>
</div>
<p>

                    </form>
<p>
</div>
<p>

                 
</div>
<p>
</body>
</html>
