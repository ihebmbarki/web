<?php
    include "config.php";
$nom = $_POST['nom'];

if(empty($nom)){
    $make = '<h4>You must type a word to search!</h4>';
}else{
    $make = '<h4>No match found!</h4>';
    $sele = "SELECT * FROM event WHERE nom LIKE '%$nom%'";
    $db = config::getConnexion();
     try {
            $sth = $db->prepare($sele);
            $sth->execute();
            $liste = $sth->fetchAll();
            return $liste;
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    
    if($row = mysqli_num_rows($liste) > 0){
         foreach($liste as $row)
                             {
                                     echo "<tr>";
                                     echo "<td>".$row['id']."</td>";
                                     echo "<td>".$row['nom']."</td>";
                                     echo "<td>".$row['theme']."</td>";}
}else{
echo'<h2> Search Result</h2>';

print ($make);
}
mysqli_free_result($liste);
mysqli_close($db);
}
     
?>