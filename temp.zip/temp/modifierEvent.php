<?PHP
include "crud.php";
$crud=new crud();
$res=$crud->getEvent($_GET['id']);
//var_dump($res);
if (isset ($_GET["modifier"])){
//$crud->modifierEvent()
}

?>
<form form action="modif.php" method="POST">
    <table>
        <tr>
            <td>id</td>
            <td><input type="text" name="id" value="<?PHP echo $_GET['id']; ?>" ></td>
        </tr>
        <tr>
            <td>Nom</td>
            <td><input type="text" name="nom" value="<?PHP echo $res['nom']; ?>"></td>
        </tr>
        <tr>
            <td>Theme</td>
            <td><input type="text" name="theme" value="<?PHP echo $res['theme']; ?>"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" value="modifier" ></td>
        </tr>
    </table>
</form>