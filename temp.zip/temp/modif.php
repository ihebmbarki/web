<?php
include "Event.php";
include "crud.php";

$E2=new Event();
$id=$_POST['id'];
$E2->setId($_POST['id']);
$E2->setNom($_POST['nom']);
$E2->setTheme($_POST['theme']);

$c=new crud();
$c->modifierEvent($E2,$id);