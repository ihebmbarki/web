<?PHP
include "crud.php";
$crud=new crud();
$res=$crud->getPlanning($_GET['id']);
//var_dump($res);
if (isset ($_GET["modifier"])){
//$crud->modifierEvent()
}

?>
<form form action="modifPlan.php" method="POST">
    <table>
        <tr>
            <td>id</td>
            <td><input type="text" name="id" value="<?PHP echo $_GET['id']; ?>" ></td>
        </tr>
        <tr>
            <td>Nom</td>
            <td><input type="text" name="lieu" value="<?PHP echo $res['lieu']; ?>"></td>
        </tr>
        <tr>
            <td>Theme</td>
            <td><input type="text" name="dat" value="<?PHP echo $res['dat']; ?>"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" value="modifier" ></td>
        </tr>
    </table>
</form>